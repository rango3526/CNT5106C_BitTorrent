public class Request {
    public static byte[] GenerateRequestMessage(int pieceIndex) {
        throw new UnsupportedOperationException();
    }

    public static void ReceivedRequestMessage(int pieceIndexRequested) {
        
    }
}
