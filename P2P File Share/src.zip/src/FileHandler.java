import java.util.HashMap;

public class FileHandler {
    HashMap<Integer, byte[]> pieceMap = new HashMap<Integer, byte[]>();

    public static byte[] GetFilePiece(int pieceIndex) {
        throw new UnsupportedOperationException();
    }

    public static void InitializePieceMapFromCompleteFile() {
        throw new UnsupportedOperationException();
    }

    public static byte[] CombinePiecesIntoCompleteFile() {
        throw new UnsupportedOperationException();
    }
}
